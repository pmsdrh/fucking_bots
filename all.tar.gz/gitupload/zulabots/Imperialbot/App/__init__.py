from telebot import TeleBot
from App.config import TOKEN

bot = TeleBot(TOKEN)