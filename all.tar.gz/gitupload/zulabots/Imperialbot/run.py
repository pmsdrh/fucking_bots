from Bot import bot

bot.polling()