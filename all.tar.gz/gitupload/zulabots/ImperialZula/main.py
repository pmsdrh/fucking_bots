import telebot
import time as tm
import os
import sys
import requests

from config import *
from telebot import *

def getfile(filename):
    file = open(filename)

    f=file.readlines()
    file.close()
    return f

def putfile(filename,filedata):
    file = open(filename, "w")

    file.writelines(filedata)

    file.close()

amar = {}
amar2 = {}
amar3 = {}
def owner():
    file1 = open('data/owner')

    return file1.read().split('\n')

    file1.close()
def admin():
    file2 = open('data/admin')
    return file2.read().split('\n')
    file2.close()

def mention(first_name, id):
    return f'[{first_name}](tg://user?id={id})'

global timedown

timedown = {}

accepted = {}

boton = {'on' : True}
botad = {'on' : True}

bot = telebot.TeleBot(token)

amartd = {
    'amartoday' : 0,
    'adstoday' : 0,
    'bantd' : 0,
    'acptd' : 0,
    'rmvtd' : 0,
    'unbantd' : 0,
    }

ysday = {
    'amartoday' : 0,
    'adstoday' : 0,
    'bantd' : 0,
    'acptd' : 0,
    'rmvtd' : 0,
    'unbantd' : 0,
    }

os.system('clear')
bot.remove_webhook()
os.system('figlet "  ImPeRiAlZuLa" | lolcat')

f = "\n \033[01;30m Bot Firstname: {} \033[0m".format(bot.get_me().first_name)
u = "\n\n \033[01;34m Bot username: {} \033[0m".format(bot.get_me().username)
i = "\n\n \033[01;32m Bot ID: {} \033[0m".format(bot.get_me().id)
c = "\n\n \033[01;31m Thank You Dady :)  I`m Fully Online Now :D \033[0m"

print(f,u,i,c)

@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    try:
        if call.message.chat.id == ids['getad']:
            if str(call.from_user.id) in owner() or str(call.from_user.id) in admin():
                if call.data[:4] == 'rmv-':
                    text = call.data.replace('rmv-', '')

                    bot.send_message(int(text), texts['rmvad'])

                    bot.edit_message_text(call.message.text + '\n' + ibtn['rmv'], call.message.chat.id, call.message.message_id,
                    reply_markup = types.InlineKeyboardMarkup(row_width = 2).add(types.InlineKeyboardButton(call.from_user.first_name + ibtn['rmv'], callback_data='agn')))

                    timedown.update({int(text) : tm.time()})

                    if '@' + str(call.from_user.username) in amar3:
                        amar3.update({'@' + str(call.from_user.username) : amar3['@' + str(call.from_user.username)] + 1})
                    else:
                        amar3.update({'@' + str(call.from_user.username) : 1})

                    amartd.update({'rmvtd' : amartd['rmvtd'] + 1})
                    amartd.update({'adstoday' : amartd['adstoday'] + 1})

                elif call.data == 'agn':
                    bot.answer_callback_query(call.id, 'این آگهی قبلا بررسی شده :)')

            if call.data[:4] == 'ban-':
                if str(call.from_user.id) in owner():
                    text = call.data.replace('ban-' , '')
                    text = int(text)

                    putfile('data/banlist', getfile('data/banlist') + [str(text) + '\n'])

                    bot.send_message(text, texts['banad'])

                    bot.edit_message_text(call.message.text + '\n' + ibtn['ban'], call.message.chat.id, call.message.message_id,
                    reply_markup = types.InlineKeyboardMarkup(row_width = 2).add(types.InlineKeyboardButton(call.from_user.first_name + ibtn['ban'], callback_data='agn')))

                    if '@' + str(call.from_user.username) in amar2:
                        amar2.update({'@' + str(call.from_user.username) : amar2['@' + str(call.from_user.username)] + 1})
                    else:
                        amar2.update({'@' + str(call.from_user.username) : 1})

                    amartd.update({'bantd' : amartd['bantd'] + 1})
                    amartd.update({'adstoday' : amartd['adstoday'] + 1})

                else:
                    bot.answer_callback_query(call.id, 'دهنت هنوز بو شیر میده ')
            if str(call.from_user.id) in owner() or str(call.from_user.id) in admin():
                if call.data[:4] == 'acp-':
                    text = call.data.replace('acp-', '')

                    bot.send_message(int(text), texts['acptad'])

                    bot.edit_message_text(call.message.text + '\n' + ibtn['acp'], call.message.chat.id, call.message.message_id,
                    reply_markup = types.InlineKeyboardMarkup(row_width = 2).add(types.InlineKeyboardButton(call.from_user.first_name + ibtn['acp'], callback_data='agn')))

                    if call.message.reply_to_message.content_type == 'photo':
                        bot.send_photo(ids['cnlid'][0], call.message.reply_to_message.photo[-1].file_id, caption = str(call.message.reply_to_message.caption) + texts['Signature'], reply_markup=reportBtn(call.message.reply_to_message.message_id))
                        bot.send_photo(ids['cnlid'][1], call.message.reply_to_message.photo[-1].file_id, caption = str(call.message.reply_to_message.caption) + texts['Signature'], reply_markup=reportBtn(call.message.reply_to_message.message_id))
                        bot.send_photo(ids['cnlid'][2], call.message.reply_to_message.photo[-1].file_id, caption = str(call.message.reply_to_message.caption) + texts['Signature'], reply_markup=reportBtn(call.message.reply_to_message.message_id))
                        # print(call.message.reply_to_message.photo[-1])
                    elif call.message.reply_to_message.content_type == 'text':
                        bot.send_message(ids['cnlid'][0], str(call.message.reply_to_message.text) + texts['Signature'], reply_markup=reportBtn(call.message.reply_to_message.message_id))
                        bot.send_message(ids['cnlid'][1], str(call.message.reply_to_message.text) + texts['Signature'], reply_markup=reportBtn(call.message.reply_to_message.message_id))
                        bot.send_message(ids['cnlid'][2], str(call.message.reply_to_message.text) + texts['Signature'], reply_markup=reportBtn(call.message.reply_to_message.message_id))

                    timedown.update({int(text) : tm.time() + cooldowntime})

                    if '@' + str(call.from_user.username) in amar:
                        amar.update({'@' + str(call.from_user.username) : amar['@' + str(call.from_user.username)] + 1})
                    else:
                        amar.update({'@' + str(call.from_user.username) : 1})

                    amartd.update({'acptd' : amartd['acptd'] + 1})
                    amartd.update({'adstoday' : amartd['adstoday'] + 1})



        if call.message.chat.id == ids['getmed']:
            if str(call.from_user.id) in owner() or str(call.from_user.id) in admin():
                if call.data[:6] == 'acpmed':
                    text = call.data.replace('acpmed', '')

                    bot.edit_message_text(call.message.text + '\n' + ibtn['acp'], call.message.chat.id, call.message.message_id,

                    reply_markup = types.InlineKeyboardMarkup(row_width = 2).add(types.InlineKeyboardButton(call.from_user.first_name + ibtn['acp'], callback_data='agn')))

                    bot.send_message(int(text), """⭕️درخواست واسطه شما توسط """ + call.from_user.first_name + """ تایید شد
🆔 @""" + call.from_user.username + """
▬▭▬▭▬▭▬▭▬▭▬▭▬▭
@ImPZula_bot""")

                if call.data[:6] == 'rmvmed':
                    text = call.data.replace('rmvmed', '')

                    bot.edit_message_text(call.message.text + '\n' + ibtn['rmv'], call.message.chat.id, call.message.message_id,
                    reply_markup = types.InlineKeyboardMarkup(row_width = 2).add(types.InlineKeyboardButton(call.from_user.first_name + ibtn['rmv'], callback_data='agn')))

                    bot.send_message(int(text), "درخواست واسطه شما رد شد!")

        if call.message.chat.type == 'private':
            if call.data[:4] == 'rep-':
                bot.edit_message_text('گزارش شما با موفقیت ارسال شد :)',call.message.chat.id, call.message.message_id, reply_markup=None)
                text = call.data.replace('rep-', '')
                text = text.split('$%#')
                bot.send_message(ids['report'], repText(call.message, text))

            if call.data[:4] == "get-":
                text = call.data.replace('get-', '')
                bot.send_message(ids['getmed'], getmedText(call.message, text), reply_markup = inlineAdminsKeyBoard2(str(call.message.chat.id)))
                bot.edit_message_text('درخواست شما با موفقیت ارسال شد :)',call.message.chat.id, call.message.message_id, reply_markup=None)
        if call.data == 'cancle':
            bot.edit_message_text('لغو شد', call.message.chat.id, call.message.message_id, reply_markup = None)
    except Exception as e:
        print(e, call.message.chat.username)
        bot.send_message(call.message.chat.id, 'حس میکنم داری اشتباه میزنی!')

@bot.message_handler(commands=['getad'])
def getme(message):
    try:
        if str(message.from_user.id) in owner() or str(message.from_user.id) in admin():
            if message.chat.id == ids['getad']:
                code = message.text.replace('/getad ' , '')
                bot.send_message(message.chat.id, 'اینجا ☝🏻', reply_to_message_id=int(code))
            else:
                code = message.text.replace('/getad ' , '')
                bot.reply_to(message, link + str(code))


    except Exception as e:
        print(e)
        bot.reply_to(message, 'حس میکنم داری اشتباه میزنی')

@bot.message_handler(commands=['getme'])
def getme(message):
    print(message.reply_to_message)

@bot.message_handler(commands=['ban'])
def ban(message):
    try:
        if str(message.from_user.id) in owner():
            text = message.reply_to_message.text.split('\n')[3]
            if text + '\n' in getfile('data/banlist'):
                bot.reply_to(message, 'کاربر در حالت بن میباشد')
            else:
                putfile('data/banlist', getfile('data/banlist') + [str(text[6:]) + '\n'])
                bot.reply_to(message, 'کاربر شما بن شد')
                bot.send_message(int(text[6:]), texts['banad'])

                amartd.update({'bantd' : amartd['bantd'] + 1})

    except Exception as e:
        print(e)
        bot.reply_to(message, 'حس میکنم داری اشتباه میزنی')

@bot.message_handler(commands=['unban'])
def unban(message):
    try:
        if str(message.from_user.id) in owner():
            text = message.reply_to_message.text.split('\n')[3]
            text = text[6:]
            ffile = open('data/banlist', 'r')
            
            if text + '\n' in getfile('data/banlist'):
                putfile('data/banlist', ffile.read().replace(text + '\n', ''))
                bot.reply_to(message, 'کاربر از حالت بن خارج شد!')

                amartd.update({'unbantd' : amartd['unbantd'] + 1})
            else:
                putfile('data/banlist', getfile('data/banlist') + [str(text[6:]) + '\n'])
                bot.reply_to(message, 'کاربر در حالت بن قرار ندارد ')
            ffile.close()

    except Exception as e:
        print(e)
        bot.reply_to(message, 'حس میکنم داری اشتباه میزنی')

@bot.message_handler(commands=['owner'])
def ownerf(message):
    try:
        # print(message.from_user.id)
        if str(message.reply_to_message.from_user.id) in owner():
            if str(message.from_user.id) in owner():
                putfile('data/owner', getfile('data/owner') + [str(message.reply_to_message.from_user.id) + '\n'])
                bot.reply_to(message, 'کاربر به عنوان موسس انتخاب شد')

    except Exception as e:
        print(e)
        bot.reply_to(message, 'یه مشکلی پیش اومده')

@bot.message_handler(commands=['admin'])
def adminf(message):
    try:
        # print(message.from_user.id)
        if str(message.from_user.id) in owner():
            putfile('data/admin', getfile('data/admin') + [str(message.reply_to_message.from_user.id) + '\n'])
            bot.reply_to(message, 'کاربر به عنوان ادمین انتخاب شد')

    except Exception as e:
        print(e)
        bot.reply_to(message, 'یه مشکلی پیش اومده')


# @bot.message_handler(commands=['getme'])
# def getme(message):
#     print(message.chat.id)

@bot.message_handler(commands=['amar'])
def amarf(message, no=False):
    try:
        txtprg = message.text.replace('/amar ', '')
        # print(message.from_user.id)
        if str(message.from_user.id) in owner() or no == True:
            if txtprg == 'yd':
                bot.reply_to(message, 'ﺖﻋﺩﺍﺩ کﻝ: '
                    + str(len(getfile('data/allusers')))
                    + '\n ﺖﻋﺩﺍﺩ کﻝ کﺍﺮﺑﺭﺎﻧ ﺎﻣﺭﻭﺯ: '
                    + str(ysday['amartoday'])
                    + '\n ﺖﻋﺩﺍﺩ کﻝ کﺍﺮﺑﺭﺎﻧ ﺐﻧ ﺵﺪﻫ: '
                    + str(len(getfile('data/banlist')))
                    + '\nﺖﻋﺩﺍﺩ ﺐﻧ ﻩﺍی ﺎﻣﺭﻭﺯ: '
                    + str(ysday['bantd'])
                    + '\nﺖﻋﺩﺍﺩ ﺂﻧ ﺐﻧ ﻩﺍی ﺎﻣﺭﻭﺯ: '
                    + str(ysday['unbantd'])
                    + '\nﺁگﻩی ﻩﺍی ﺕﺍییﺩ ﺵﺪﻫ ﺎﻣﺭﻭﺯ: '
                    + str(ysday['acptd'])
                    + '\nﺁگﻩی ﻩﺍی ﺭﺩ ﺵﺪﻫ ﺎﻣﺭﻭﺯ: '
                    + str(ysday['rmvtd'])
                    + '\nﺖﻋﺩﺍﺩ کﻝ ﺁگﻩی ﻩﺍ: '
                    + str(ysday['adstoday'])
                    )

                return

            b = ''
            c = ''
            d = ''

            for item in amar.keys():
                b = b + str(item) + ':' + str(amar[item]) + '\n'

            for item in amar3.keys():
                c = c + str(item) + ':' + str(amar3[item]) + '\n'

            for item in amar2.keys():
                d = d + str(item) + ':' + str(amar2[item]) + '\n'

            bot.reply_to(message, 'تعداد کل: '
            + str(len(getfile('data/allusers')))
            + '\n تعداد کل کاربران امروز: '
            + str(amartd['amartoday'])
            + '\n تعداد کل کاربران بن شده: '
            + str(len(getfile('data/banlist')))
            + '\nتعداد بن های امروز: '
            + str(amartd['bantd'])
            + '\nتعداد آن بن های امروز: '
            + str(amartd['unbantd'])
            + '\nآگهی های تایید شده امروز: '
            + str(amartd['acptd'])
            + '\nآگهی های رد شده امروز: '
            + str(amartd['rmvtd'])
            + '\nتعداد کل آگهی ها: '
            + str(amartd['adstoday'])
            )
            bot.send_message(message.chat.id, 'آمار ثبت امروز: \n' + str(b) + 'آمار رد امروز: \n' + str(c) + 'آمار بن امروز: \n' + str(d))
    except Exception as e:
        print(e)
        bot.reply_to(message, 'یﻩ ﻢﺷکﻝی پیﺵ ﺍﻮﻣﺪﻫ')


@bot.message_handler(commands=['sendauto'])
def send(message):
    b = 0
    tstids = [-1001287823011]
    text = message.text.replace('/sendauto ', '')
    text = text.split(' ')
    try:
        if str(message.chat.id) in owner():
            for n in range(0, int(text[0])):
                for a in ids['ads']:
                    bot.forward_message(int(a), message.chat.id, message.reply_to_message.message_id)
                time.sleep(int(text[1]))
    except Exception as e:
        print(e)
        bot.reply_to(message, 'ﺢﺳ ﻡیکﻦﻣ ﺩﺍﺭی ﺎﺸﺘﺑﺎﻫ ﻡیﺰﻧی')


@bot.message_handler(commands=['send'])
def send(message):
    try:
        if str(message.chat.id) in owner():
            file = open('data/allusers', 'r')
            alluser = file.read().split('\n')
            file.close()
            b = 0
            for a in alluser:
                if not(a == ''):
                    try:
                        bot.send_message(int(a), message.reply_to_message.text)
                    except Exception as e:
                        b = b + 1
            bot.send_message(message.chat.id, str(b))

    except Exception as e:
        print(e)
        bot.reply_to(message, 'حس میکنم داری اشتباه میزنی')

@bot.message_handler(commands=['send2'])
def send2(message):
    try:
        if str(message.chat.id) in owner():
            file = open('data/allusers', 'r')
            alluser = file.read().split('\n')
            file.close()
            b = 0
            for a in alluser:
                if not(a == ''):
                    # print(message.reply_to_message.message_id)
                    try:
                        bot.forward_message(int(a), message.chat.id, message.reply_to_message.message_id)
                    except Exception as e:
                        b = b + 1
            
            bot.send_message(message.chat.id, str(b))

    except Exception as e:
        print(e)
        bot.reply_to(message, ' حس میکنم داری اشتباه میزنی')


@bot.message_handler(commands=['list'])
def listf(message):
    # try:
    a = ''
    b = ''
    for i in owner():
        a += str(mention(bot.get_chat(int(i)).first_name, int(i))) + '\n'
        
    for i in admin():
        b += str(mention(bot.get_chat(int(i)).first_name, int(i))) + '\n'
    print(a,b)
    # for i in owner():
        # a += mention(bot.get_chat(int(i)).first_name, int(i))
    
    mystr = f"لیست موسسان: \n{a}\nلیست مدیران: \n{b}\nلیست واسط ها:\n"
    bot.reply_to(message, mystr, parse_mode='Markdown')
        
    # except Exception as e:
        # bot.reply_to(message, e)


@bot.message_handler(commands=['send3'])
def send3(message):
    try:
        if str(message.chat.id) in owner():
            for a in ids['ads']:
                # if not(a == ''):
                    # print(message.reply_to_message.message_id)
                bot.forward_message(int(a), message.chat.id, message.reply_to_message.message_id)

    except Exception as e:
        print(e)
        bot.reply_to(message, 'حس میکنم داری اشتباه میزنی')

@bot.message_handler(commands=['s'])
def replyto(message):
    try:
        if str(message.from_user.id) in owner() or str(message.from_user.id) in admin():
            text = message.reply_to_message.text.split('\n')[3]
            text2 = message.text.replace('/s ', '')

            bot.send_message(text[6:], text2)

            bot.reply_to(message, ' پیغام شما با موفقیت ارسال شد ')
    except Exception as e:
        print(e)
        bot.reply_to(message, 'حس میکنم داری اشتباه میزنی')


@bot.message_handler(commands=['close'])
def closes(message):
    try:
        text = message.text.replace('/close ', '')

        if text == 'bot':
            if str(message.from_user.id) in owner():
                boton.update({'on' : False})
                bot.reply_to(message, 'ربات کاملا خاموش شد')
                amarf(message)

        elif text == 'ad':
            if str(message.from_user.id) in owner() or str(message.from_user.id) in admin():
                amarf(message, no=True)
                botad.update({'on' : False})
                bot.reply_to(message, 'ارسال آگهی بسته شد!')
                ysday.update(amartd)
                amartd.update({
                    'amartoday' : 0,
                    'adstoday' : 0,
                    'bantd' : 0,
                    'acptd' : 0,
                    'rmvtd' : 0,
                    'unbantd' : 0,
                    })
                amar.clear()
                amar2.clear()
                amar3.clear()


    except Exception as e:
        print(e)
        bot.reply_to(message, 'یه مشکلی پیش اومده')

@bot.message_handler(commands=['open'])
def openes(message):
    try:
        text = message.text.replace('/open ', '')
        if text == 'bot':
            if str(message.from_user.id) in owner():
                boton.update({'on' : True})
                bot.reply_to(message, 'ربات با موفقیت روشن شد')
        elif text == 'ad':
            if str(message.from_user.id) in owner() or str(message.from_user.id) in admin():
                botad.update({'on' : True})
                bot.reply_to(message, 'ارسال آگهی باز شد!')

    except Exception as e:
        print(e)
        bot.reply_to(message, 'حس میکنم داری اشتباه میزنی')

@bot.message_handler(commands=['start'])
def startbot(message):
    try:
        url = "https://api.telegram.org/bot" + token + "/"
        params1 = {'chat_id': ids['join'][0], 'user_id': message.chat.id}
        params2 = {'chat_id': ids['join'][1], 'user_id': message.chat.id}
        response1 = requests.post(url + 'getChatMember', data=params1)
        response2 = requests.post(url + 'getChatMember', data=params2)

        jn1 = response1.json()['ok']
        jn2 = response2.json()['ok']

        if message.chat.type == 'private':
            if jn1 and not(response1.json()['result']['status'] == 'left') and jn2 and not(response2.json()['result']['status'] == 'left'):
                if message.text[:14] == '/start report-':
                    text = message.text.replace('/start report-', '')
                    bot.reply_to(message, texts['report'], reply_markup = forKeyBoard(ibtn['reportK'], text))
                else:
                    file = open('data/allusers', 'r')
                    alluser = file.read().split('\n')
                    file.close()

                    if str(message.chat.id) in alluser:
                        pass
                    else:
                        putfile('data/allusers', getfile('data/allusers') + [str(message.chat.id) + '\n'] )
                        amartd.update({'amartoday' : amartd['amartoday'] + 1})

                    bot.reply_to(message, texts['start'], reply_markup = mainKeyBoard())
            else:
                bot.reply_to(message, texts['join'], reply_markup=joinBtn())

    except Exception as e:
        print(e, message.chat.username)
        bot.reply_to(message, 'یه مشکلی پیش اومده! لطفا به ادمین اطلاع بده')

@bot.message_handler(content_types=['text'])
def botmain(message):
    try:
        url = "https://api.telegram.org/bot" + token + "/"
        params1 = {'chat_id': ids['join'][0], 'user_id': message.chat.id}
        params2 = {'chat_id': ids['join'][1], 'user_id': message.chat.id}
        response1 = requests.post(url + 'getChatMember', data=params1)
        response2 = requests.post(url + 'getChatMember', data=params2)

        jn1 = response1.json()['ok']
        jn2 = response2.json()['ok']

        if message.chat.type == 'private':
            if jn1 and not(response1.json()['result']['status'] == 'left') and jn2 and not(response2.json()['result']['status'] == 'left'):
                if boton['on']:
                    if not(str(message.chat.id) + '\n' in getfile('data/banlist')):
                        if message.text == btn['sendads']:
                            if botad['on']:
                                if message.chat.id in timedown:
                                    ifd = int(timedown[message.chat.id] - tm.time())
                                    h = ifd // 3600
                                    m = (ifd % 3600) // 60
                                    s = ifd % 60
                                    if ifd <= 0:
                                        m1 = bot.reply_to(message, texts['sendads'], reply_markup = backKeyBoard())
                                        bot.register_next_step_handler(m1, getad)
                                    else:
                                        bot.reply_to(message, timetext(h,m,s))
                                else:
                                    m1 = bot.reply_to(message, texts['sendads'], reply_markup = backKeyBoard())
                                    bot.register_next_step_handler(m1, getad)
                            else:
                                bot.reply_to(message, 'ارسال آگهی در این ساعت بسته میباشد')

                        elif message.text == btn['back']:
                            bot.reply_to(message, texts['start'], reply_markup = mainKeyBoard())

                        elif message.text == btn['fakeid']:
                            m1 = bot.reply_to(message, texts['fakeid'], reply_markup = backKeyBoard())
                            bot.register_next_step_handler(m1, fakeid)

                        elif message.text == btn['info']:
                            bot.reply_to(message, texts['info'])

                        elif message.text == btn['prices']:
                            bot.reply_to(message, texts['prices'])

                        elif message.text == btn['challenge']:
                            bot.reply_to(message, texts['challenge'])

                        elif message.text == btn['rols']:
                            bot.reply_to(message, texts['rols'])

                        elif message.text == btn['getmed']:
                            bot.reply_to(message, texts['getmed'], reply_markup=forKeyBoard2(ibtn['medbtn']))
                        
                        elif message.text == btn['support']:
                            m1 = bot.reply_to(message, texts['support'], reply_markup=backKeyBoard())
                            bot.register_next_step_handler(m1, support)
                    else:
                        bot.reply_to(message, texts['banU'])
                else:
                    bot.reply_to(message, 'ربات توسط یکی از ادمین ها خاموش شده است!')
            else:
                bot.reply_to(message, texts['join'], reply_markup = joinBtn())

    except Exception as e:
        print(e, message.chat.username)
        bot.reply_to(message, 'یه مشکلی پیش اومده! لطفا به ادمین اطلاع بده')


def getad(message):
    try:
        if message.content_type == 'text' or message.content_type == 'photo':
            if message.text == btn['back']:
                bot.reply_to(message, texts['start'], reply_markup = mainKeyBoard())

            else:
                if message.chat.id in timedown:
                    ifd = int(timedown[message.chat.id] - tm.time())
                    h = ifd // 3600
                    m = (ifd % 3600) // 60
                    s = ifd % 60

                    if ifd <= 0:
                        m1 = bot.forward_message(ids['getad'], message.chat.id, message.message_id)
                        m2 = bot.reply_to(m1,
                        'Name: ' + message.chat.first_name + '\nUserName: @' + str(message.chat.username) + '\nCode: #c' + str(m1.message_id) + '\nFrom: ' + str(message.chat.id),
                        reply_markup = inlineAdminsKeyBoard(str(message.chat.id)))

                        bot.reply_to(message, texts['sendads2'], reply_markup = mainKeyBoard())

                        timedown.update({message.chat.id : tm.time() + cooldowntime // 4})
                        # print(timedown)

                    else:
                        timedown.update({message.chat.id : timedown[message.chat.id] + 3600})
                        bot.reply_to(message, 'به علت اسپم یک ساعت دیگه جریمه شدی')

                else:
                    m1 = bot.forward_message(ids['getad'], message.chat.id, message.message_id)
                    m2 = bot.reply_to(m1,
                    'Name: ' + message.chat.first_name + '\nUserName: @' + str(message.chat.username) + '\nCode: #c' + str(m1.message_id) + '\nFrom: ' + str(message.chat.id),
                    reply_markup = inlineAdminsKeyBoard(str(message.chat.id)))
                    bot.reply_to(message, texts['sendads2'], reply_markup = mainKeyBoard())
                    timedown.update({message.chat.id : tm.time() + cooldowntime // 4})
                    # print(timedown)
        else:
            bot.reply_to(message, texts['notsup'])

    except Exception as e:
        print(e, message.chat.username)
        bot.send_message(message.chat.id, 'حس میکنم داری اشتباه میزنی')


def fakeid(message):
    try:
        if message.text == btn['back']:
            bot.reply_to(message, texts['start'], reply_markup = mainKeyBoard())
            return

        done = False
        for a in nfids:
            if message.text.lower() == a.lower():
                done = True
        if done:
            bot.reply_to(message, '✅ این کاربر از واسط های مجموعه ایمپریال میباشد', reply_markup = mainKeyBoard())
        else:
            bot.reply_to(message, '❌ این کاربر از واسط های مجموعه امپریال نمیباشد', reply_markup = mainKeyBoard())

    except Exception as e:
        print(e, message.chat.id)
        bot.reply_to(message, 'حس میکنم داری اشتباه میزنی')


def support(message):
    try:
        if message.text == btn['back']:
            bot.reply_to(message, texts['start'], reply_markup=mainKeyBoard())
        else:
            m1 = bot.forward_message(ids['support'], message.chat.id, message.message_id)
            m2 = bot.reply_to(m1,
                    'Name: ' + '<a href="tg://user?id=' + str(message.chat.id) + '">'+  message.chat.first_name + '</a>' +  '\nUserName: @' + str(message.chat.username) + '\n' + '\nFrom: ' + str(message.chat.id), parse_mode='HTML')
            bot.reply_to(message,
        text='پیغام شما با موفقیت به بخش پشتیبانی ارسال شد ✅\nپس از بررسی در اسرع وقت به شما پاسخ داده می شود'
        ,reply_markup = mainKeyBoard(),
        parse_mode='HTML')
    except Exception as e:
        print(str(e) + message.chat.username)
        bot.reply_to(message, 'حس میکنم داری اشتباه میزنی')

def mainKeyBoard():
    k = types.ReplyKeyboardMarkup(resize_keyboard=True)
    k.add(
        types.KeyboardButton(btn['sendads']),
        types.KeyboardButton(btn['getmed'])
        )

    k.add(
        types.KeyboardButton(btn['challenge']),
        types.KeyboardButton(btn['fakeid'])
        )

    k.add(
            types.KeyboardButton(btn['prices']),
            types.KeyboardButton(btn['rols'])
            )

    k.add(
        types.KeyboardButton(btn['info']),
        types.KeyboardButton(btn['support']),
        )
    return k

def backKeyBoard():
    return types.ReplyKeyboardMarkup(one_time_keyboard=True, resize_keyboard=True).add(types.KeyboardButton(btn['back']))

def inlineAdminsKeyBoard(m):
    return types.InlineKeyboardMarkup(row_width = 2).add(
        types.InlineKeyboardButton(ibtn['acp'], callback_data='acp-' + m),
        types.InlineKeyboardButton(ibtn['rmv'], callback_data='rmv-' + m),
        types.InlineKeyboardButton(ibtn['ban'], callback_data='ban-' + m))

def inlineAdminsKeyBoard2(m):
    return types.InlineKeyboardMarkup(row_width = 2).add(types.InlineKeyboardButton(ibtn['acp'], callback_data='acpmed'+m),types.InlineKeyboardButton(ibtn['rmv'], callback_data='rmvmed'+m))

def reportBtn(m):
    return types.InlineKeyboardMarkup(row_width = 2).add(types.InlineKeyboardButton(ibtn['report'], url='https://t.me/' + bot.get_me().username + '?start=report-' + str(m)))

def forKeyBoard(kry, b):
    k = types.InlineKeyboardMarkup()
    for a in kry:
        k.add(types.InlineKeyboardButton(a, callback_data='rep-' + a + '$%#' + b))
    k.add(types.InlineKeyboardButton('لغو', callback_data='cancle'))
    k.row_width = 2
    return k

def forKeyBoard2(kry):
    k = types.InlineKeyboardMarkup()
    for a in kry:
         k.add(types.InlineKeyboardButton(a, callback_data='get-' + a ))
    k.add(types.InlineKeyboardButton('لغو', callback_data='cancle'))

    k.row_width = 2
    return k

def joinBtn():
    return types.InlineKeyboardMarkup(row_width = 1).add(
        types.InlineKeyboardButton('♦️ ImPeRiAl ZuLa',
        url='https://t.me/ImPeRiAlZuLa'),
        types.InlineKeyboardButton('♦️ ImPeRiAlZuLa V.I.P',
        url='https://t.me/ImPeRiAlZuLaVIP'),
        types.InlineKeyboardButton('جوین شدم ✅',
        url='https://t.me/' + bot.get_me().username + '?start=new'),
        )

while True:
    time.sleep(3)
    try:
        bot.polling(none_stop=True)
    except Exception as e:
        if e == KeyboardInterrupt:
            break
