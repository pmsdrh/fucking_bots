from telebot import TeleBot
import json
import os
import random

from telebot.types import ReplyKeyboardMarkup,  InlineKeyboardMarkup, InlineKeyboardButton

from models.buttons import Buttons



#Load questions & answers
with open("data/q-a.json", 'r') as f:
    qss = json.load(f)

# Load 'banlist' to check or ban users
with open("data/banlist.json", 'r') as f:
    banlist = json.load(f)

with open("data/allusers.json", 'r') as f:
    allusers = json.load(f)

class Main(Buttons):

    # Load 'Config' file
    with open("config.json", 'r') as f:
        config = json.load(f)

    bot = TeleBot(config['token'])
    
    # This is the group to which the answers are sent
    group_admin = -1001343815869
    
    icons = ["❤️", "💚", "💙", "💛"]


    def __init__(self):
    
        Buttons.__init__(self, self.config)
                
        #Handle /start
        @self.bot.message_handler(commands=["start"], func=lambda message: message.chat.type=="private")
        def msg(message):
            if str(message.chat.id) in banlist:
                if banlist[str(message.chat.id)] == 3:
                    self.bot.reply_to(message, "شما از ربات بن شده اید!")
                    return
            try:
                self.bot.send_message(message.chat.id, self.config['start_text'], 
                reply_markup=self.main_buttons())
                if not(message.chat.id in allusers):
                    allusers.append(message.chat.id)
                    with open("data/allusers.json", 'w') as f:
                        json.dump(allusers, f, indent=4)
                    
            except Exception as e:
                Exception_Handler(e, message)
        
        #Handle /info
        @self.bot.message_handler(commands=["info"])
        def msg(message):
            self.bot.reply_to(message, self.config['info_text'])

        @self.bot.message_handler(commands=["send"], func=lambda message: message.chat.id == self.group_admin)
        def msg(message):
            self.bot.reply_to(message, "در حال انجام")
            gp = message.text.replace("/send ", "")
            with open(f"data/groups/{gp}.json", "r") as f:
                gp_members = json.load(f)
                for i in gp_members:
                    try:
                        self.bot.forward_message(i, message.chat.id, message.reply_to_message.message_id)
                    except:
                        self.bot.reply_to(message, "[{}](tg://user?id={})".format(i, i), parse_mode="Markdown")
                        
                self.bot.reply_to(message, "به اتمام رسید!")

        
        @self.bot.message_handler(content_types=['text'],
        func=lambda message: message.chat.type == "supergroup")
        def msg(message):
            if message.text == "آمار":
                statistics = ""
                service = ["groups/gryffindor", "groups/slytherin", "groups/ravenclaw", "groups/hufflepuff", "banlist", "allusers"]
                for i in service:
                    with open(f'data/{i}.json', 'r') as f:
                        dic = json.load(f)
                        statistics += i + " : " + str(len(dic)) + '\n'
                        
                
                self.bot.reply_to(message, statistics)

            if message.text == "HiChat":
                print(message.chat.id)
                
            
            if message.text == "ریچک":
                self.bot.reply_to(message, "ربات در حال ریچک است لطفا تا پایان عملیات از ربات استفاده نکنید!")
                mp = []
                for i in os.listdir("data/users"):
                    j = self.bot.get_chat_member(-1001150426191, int(i.replace('.json', "")))
                    if not( j.status == 'left' ):
                        mp.append(i.replace('.json', ""))
                
                next_text = ""
                sl = 100
                for i in mp:
                    sl +=1
                    next_text += "[{}](tg://user?id={})".format(str(sl), i) + " | "
                    
                bot.send_message(message.chat.id, next_text, parse_mode="Markdown")
                bot.send_message(message.chat.id, 'No error!! Cunnilingus...')
            
            if "حذف از " in message.text:
                dale = message.text.replace("حذف از ", "")
                dale = dale.split(" ")
                
            if "بن" == message.text[:2]:
                
                if message.reply_to_message:
                    user = message.reply_to_message.text.split("\n")[-1]
                                            
                elif message.text.split(" ").__len__() == 2:
                    user = message.text.split(" ")[-1]
                
                else:
                    bot.reply_to(message, "کاربر یافت نشد!")
                    return
                
                try:
                    try:
                        str(int(user))
                    except:
                        bot.reply_to(message, "کاربر یافت نشد!")
                        return
                        
                        
                    with open("data/banlist.json", 'w') as f:
                        banlist.update({user : 3})
                        json.dump(banlist, f, indent=4)
                        
                    try:
                        self.bot.send_message(int(user), "شما توسط یکی از ناظران از ربات مسدود شدید!")
                        self.bot.reply_to(message, "[{}](tg://user?id={}) مسدود شد!".format(user, user), parse_mode="Markdown")
                    except:
                        self.bot.reply_to(message, "[{}](tg://user?id={}) ربات را بلاک کرده است!".format(user, user), parse_mode="Markdown")
                except:
                    pass

                
        @self.bot.message_handler(content_types=['text'], 
            func=lambda message: message.chat.type=="private")
        def msg(message):
            if str(message.chat.id) in banlist:
                if banlist[str(message.chat.id)] == 3:
                    self.bot.reply_to(message, "شما از ربات بن شده اید!")
                    return

            if message.text == self.config['startTest_button']:
            
                # Set the error to test again
                if os.path.exists(f'data/users/{message.chat.id}.json'):
                    self.bot.reply_to(message, self.config['retestError_text'])
                    return
                
                with open(f"data/users/{message.chat.id}.json", "w") as f:
                    f.write("{}")

                lss = random.sample(qss[list(qss.keys())[0]],len(qss[list(qss.keys())[0]]))
                self.bot.reply_to(message, list(qss.keys())[0] + ''.join('\n' + i for i in lss),
                reply_markup=self.get_a_buttons(lss))

        @self.bot.callback_query_handler(func=lambda call: True)
        def callback_handler(call):
            if "answer:" in call.data:
                answer_number = int(call.data.replace("answer:", ""))
                answer = call.message.text.split('\n')[answer_number + 1]
                with open(f"data/users/{call.message.chat.id}.json", "r") as f:
                    dic = json.load(f)
                    dic.update({call.message.text.split('\n')[0] : answer})
                    
                with open(f"data/users/{call.message.chat.id}.json", "w") as f:
                    json.dump(dic, f, indent=4)
                    
                self.bot.edit_message_text(call.message.text.split('\n')[0] + "\n✅" + answer, call.message.chat.id, call.message.message_id)
                self.bot.answer_callback_query(call.id, "ثبت شد ✅")
                
                if list(qss.keys()).index(call.message.text.split('\n')[0]) + 1 == len(list(qss.keys())):
                    self.bot.send_message(call.message.chat.id, "تست گروهبندی شما با موفقیت انجام شد! لطفا رباتو بلاک نزنین تا جواب آزمون براتون ارسال شه :)")
                    l = ""
                    j = 0
                    for i in dic:
                        j = j + 1
                        l = l + self.icons[qss[i].index(dic[i])] + "   " + dic[i] + "\n"

                    self.bot.send_message(self.group_admin, l + '\n' + "[{}](tg://user?id={})\n".format("مشاهده کاربر", call.message.chat.id) +  "@" + str(call.message.chat.username).replace("_", "\_") + '\n' + str(call.message.chat.id)
                    , reply_markup = self.group_markups(call.message.chat.id), parse_mode="Markdown")

                else:
                    question = call.message.text.split('\n')[0]
                    
                    indx = list(qss.keys()).index(question) + 1
                    
                    lss = random.sample(qss[list(qss.keys())[indx]], 
                                            len(qss[list(qss.keys())[indx]]))
                    
                    self.bot.reply_to(call.message, list(qss.keys())[indx] + ''.join('\n' + i for i in lss),
                    reply_markup=self.get_a_buttons(lss))

            elif "group:" in call.data:
                group = call.data.replace("group:", "")
                
                with open(f"data/groups/{group}.json", "r") as fr:
                    
                    dic = json.load(fr)
                    
                    with open(f"data/groups/{group}.json", "w") as fw:
                        dic.append(int(call.message.text.split('\n')[-1]))
                        json.dump(dic, fw, indent=4)
                        
                self.bot.answer_callback_query(call.id, f"set in {group}")
                
                self.bot.edit_message_text(text=call.message.text, chat_id=call.message.chat.id, message_id=call.message.message_id,
                reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton(group, callback_data="np")))
                
            elif "user:" in call.data:
                command = call.data.replace("user:", "")
                user = call.message.text.split('\n')[-1]
                
                if command == "reject":
                    
                    try:
                        os.remove(f"data/users/{user}.json")
                    except:
                        pass
                    try:
                        self.bot.send_message(user, "تست شما قابل قبل نبود! لطفا دوباره تست بده")
                    except:
                        self.bot.reply_to(call.message, "این کاربر ربات را بلاک کرده است!")
                    
                    self.bot.edit_message_text(call.message.text, call.message.chat.id, call.message.message_id,
                        reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton("❌", callback_data="np")))
                    
                elif command == "warning":
                
                    warning = 1
                    
                    if user in banlist:
                        if banlist[user] >= 3:
                            self.bot.answer_callback_query(call.id, "این کاربر هم اکنون داخل لیست بن وجود دارد!", alert=True)
                            return 
                            
                        warning = banlist[user] + 1
                    
                    with open("data/banlist.json", 'w') as f:
                        banlist.update({user : warning})
                        json.dump(banlist, f, indent=4)
                    try:
                        self.bot.send_message(user, f"کاربر گرامی شما تا کنون {warning} اخطار دریافت کردید!" + \
                        ("و به دلیل دریافت اخطار های متعدد از ربات مسدود شدید!" if warning == 3 else ""))
                    except:
                        self.bot.answer_callback_query(call.id, "این کاربر ربات را بلاک کرده است!", alert=True)

                    if warning >= 3:
                        self.bot.edit_message_text(call.message.text, call.message.chat.id, call.message.message_id,
                            reply_markup=self.unban_buttons())
                    else:
                        self.bot.edit_message_text(call.message.text, call.message.chat.id, call.message.message_id,
                            reply_markup=self.group_markups(int(user)))

                  
                elif command == "ban":
                    with open("data/banlist.json", 'w') as f:
                        banlist.update({user : 3})
                        json.dump(banlist, f, indent=4)
                        
                    try:
                        self.bot.send_message(user, "شما توسط یکی از ناظران از ربات مسدود شدید!")
                        self.bot.answer_callback_query(call.id, "کاربر مسدود شد!")
                    except:
                        self.bot.answer_callback_query(call.id, "کاربر ربات را بلاک کرده است!", alert=True)

                    self.bot.edit_message_text(call.message.text, call.message.chat.id, call.message.message_id,
                        reply_markup=self.unban_buttons())
                        
                elif command == "unban":
                    with open("data/banlist.json", 'w') as f:
                        del banlist[user]
                        json.dump(banlist, f, indent=4)
                    
                    try:
                        self.bot.send_message(user, "شما توسط یکی از ناظران رفع مسدودیت شدید!")
                        self.bot.answer_callback_query(call.id, "کاربر رفع مسدودیت شد!")
                    except:
                        self.bot.answer_callback_query(call.id, "کاربر ربات را بلاک کرده است!", alert=True)

                    self.bot.edit_message_text(call.message.text, call.message.chat.id, call.message.message_id,
                        reply_markup=self.group_markups(int(user)))
                    
    def get_a_buttons(self, lss):
        markup = InlineKeyboardMarkup()
        j = 0
        for i in lss:
            j = j + 1
            markup.add(InlineKeyboardButton("" + str(j), callback_data=f"answer:{lss.index(lss[j-1])}"))
        return markup 
    
    def group_markups(self, chat_id):
        markup = InlineKeyboardMarkup()
        markup.add(
            InlineKeyboardButton("💛", callback_data="group:hufflepuff"),
            InlineKeyboardButton("❤️", callback_data="group:gryffindor"))
        markup.add(
            InlineKeyboardButton("💚", callback_data="group:slytherin"),
            InlineKeyboardButton("💙", callback_data="group:ravenclaw"))
        
        markup.add(
            InlineKeyboardButton("🖕🏻", callback_data="user:ban"),
            InlineKeyboardButton("⚠️ " + str(banlist[str(chat_id)] if str(chat_id) in banlist else ""), callback_data="user:warning"),
            InlineKeyboardButton("❌", callback_data="user:reject")
        )
        
        return markup


class Exception_Handler(Main):
    def __init__(self, exception, message):
        self.bot.send_message(message.chat.id, str(exception))


if __name__ == "__main__":
    bot = Main().bot
    
    os.system("clear")
    
    bot.polling(none_stop=True)